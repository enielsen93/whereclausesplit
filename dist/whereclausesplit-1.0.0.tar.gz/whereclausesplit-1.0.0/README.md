# whereclausesplit
 Python Package for splitting an arcpy SQL whereclause so length does not exceed allowed characters (3000)
